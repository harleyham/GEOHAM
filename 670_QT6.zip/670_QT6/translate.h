#ifndef TRANSLATE_H
#define TRANSLATE_H

#include <QVector>
#include <QString>

int translate_HAM(int, char **);


#endif // TRANSLATE_H
