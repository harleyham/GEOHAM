#ifndef INFO_H_H
#define INFO_H_H
#include <QString>

int info_H(int argc, char **argv, QString &Out);
int info_H(QString File, QString &Out);

#endif // INFO_H_H
