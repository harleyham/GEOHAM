#ifndef CONVERSOR_COORDENADAS_H
#define CONVERSOR_COORDENADAS_H


class Conversor_Coordenadas
{
public:
    Conversor_Coordenadas();
};

#endif // CONVERSOR_COORDENADAS_H
