#ifndef CONFIG_FILE_H
#define CONFIG_FILE_H


class Config_File
{
public:
    Config_File();
};

#endif // CONFIG_FILE_H
