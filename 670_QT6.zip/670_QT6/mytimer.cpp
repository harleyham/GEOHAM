#include "mytimer.h"
#include <QDebug>

